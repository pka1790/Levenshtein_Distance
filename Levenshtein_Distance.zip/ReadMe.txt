To Run:

Run RallyHealthDistance
User Inputs:

-	Please provide inputs: 
-	1 5 1 3
-	team
-	maet

Output:
(output: 3) (team - maet)